#!/bin/sh

# Change the following address to your GRIN addr.
HOST=`ip -f inet addr show eth0 | grep -Po 'inet \K[\d.]+' | tr -d '.'`
ADDRESS=comino
USERNAME=$ADDRESS.$HOST
POOL=grin29.f2pool.com:13654
SCHEME=cuckaroo29
PWD=foo
while :; do
./bminer -uri $SCHEME://$USERNAME:$PWD@$POOL -api 127.0.0.1:1880
   sleep 12000
   echo "Killing miner"
   killall bminer
   sleep 20
   echo "Restart miner"
done

